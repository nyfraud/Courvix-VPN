﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace Courvix_VPN
{
	// Token: 0x0200000D RID: 13
	public static class SettingsManager
	{
		// Token: 0x06000031 RID: 49 RVA: 0x000042D0 File Offset: 0x000024D0
		public static void Save(this SettingsModel model)
		{
			if (!Directory.Exists(Strings.Data))
			{
				Directory.CreateDirectory(Strings.Data);
			}
			SettingsManager.settings = model;
			string contents = JsonConvert.SerializeObject(model, 1);
			File.WriteAllText(SettingsManager.jsonpath, contents);
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00004310 File Offset: 0x00002510
		public static SettingsModel Load()
		{
			if (SettingsManager.settings != null)
			{
				return SettingsManager.settings;
			}
			if (!Directory.Exists(Strings.Data))
			{
				Directory.CreateDirectory(Strings.Data);
			}
			if (!File.Exists(SettingsManager.jsonpath))
			{
				new SettingsModel().Save();
			}
			return SettingsManager.settings = JsonConvert.DeserializeObject<SettingsModel>(File.ReadAllText(SettingsManager.jsonpath));
		}

		// Token: 0x04000042 RID: 66
		private static string jsonpath = Path.Combine(Strings.Data, "settings.json");

		// Token: 0x04000043 RID: 67
		private static SettingsModel settings = null;
	}
}
