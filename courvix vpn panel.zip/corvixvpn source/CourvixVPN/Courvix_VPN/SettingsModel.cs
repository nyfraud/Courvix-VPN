﻿using System;
using Newtonsoft.Json;

namespace Courvix_VPN
{
	// Token: 0x0200000E RID: 14
	public class SettingsModel
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000034 RID: 52 RVA: 0x00004388 File Offset: 0x00002588
		// (set) Token: 0x06000035 RID: 53 RVA: 0x00004390 File Offset: 0x00002590
		[JsonProperty("DiscordRPC")]
		public bool DiscordRPC { get; set; } = true;
	}
}
