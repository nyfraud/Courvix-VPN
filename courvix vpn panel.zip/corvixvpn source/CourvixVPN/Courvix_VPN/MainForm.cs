﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Courvix_VPN.Forms;
using Courvix_VPN.Models;
using Courvix_VPN.Properties;
using DiscordRPC;
using Guna.UI2.WinForms;
using OpenVpn;

namespace Courvix_VPN
{
	// Token: 0x02000004 RID: 4
	public partial class MainForm : Form
	{
		// Token: 0x06000005 RID: 5 RVA: 0x0000220E File Offset: 0x0000040E
		public MainForm()
		{
			this.InitializeComponent();
			MainForm._client.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", string.Format("CourvixVPN Windows/{0}", Assembly.GetEntryAssembly().GetName().Version));
		}

		// Token: 0x06000006 RID: 6 RVA: 0x0000224C File Offset: 0x0000044C
		private void ConnectBTN_Click(object sender, EventArgs e)
		{
			MainForm.<ConnectBTN_Click>d__5 <ConnectBTN_Click>d__;
			<ConnectBTN_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ConnectBTN_Click>d__.<>4__this = this;
			<ConnectBTN_Click>d__.<>1__state = -1;
			<ConnectBTN_Click>d__.<>t__builder.Start<MainForm.<ConnectBTN_Click>d__5>(ref <ConnectBTN_Click>d__);
		}

		// Token: 0x06000007 RID: 7 RVA: 0x00002283 File Offset: 0x00000483
		private void Manager_Output(object sender, string output)
		{
			File.AppendAllText(Strings.OpenVpnLogs, output);
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00002290 File Offset: 0x00000490
		private Task GetConfig(Server server, bool force = true)
		{
			MainForm.<GetConfig>d__7 <GetConfig>d__;
			<GetConfig>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<GetConfig>d__.<>4__this = this;
			<GetConfig>d__.server = server;
			<GetConfig>d__.force = force;
			<GetConfig>d__.<>1__state = -1;
			<GetConfig>d__.<>t__builder.Start<MainForm.<GetConfig>d__7>(ref <GetConfig>d__);
			return <GetConfig>d__.<>t__builder.Task;
		}

		// Token: 0x06000009 RID: 9 RVA: 0x000022E4 File Offset: 0x000004E4
		private void MainForm_Load(object sender, EventArgs e)
		{
			MainForm.<MainForm_Load>d__8 <MainForm_Load>d__;
			<MainForm_Load>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<MainForm_Load>d__.<>4__this = this;
			<MainForm_Load>d__.<>1__state = -1;
			<MainForm_Load>d__.<>t__builder.Start<MainForm.<MainForm_Load>d__8>(ref <MainForm_Load>d__);
		}

		// Token: 0x0600000A RID: 10 RVA: 0x0000231C File Offset: 0x0000051C
		private Task CheckVersion()
		{
			MainForm.<CheckVersion>d__9 <CheckVersion>d__;
			<CheckVersion>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CheckVersion>d__.<>4__this = this;
			<CheckVersion>d__.<>1__state = -1;
			<CheckVersion>d__.<>t__builder.Start<MainForm.<CheckVersion>d__9>(ref <CheckVersion>d__);
			return <CheckVersion>d__.<>t__builder.Task;
		}

		// Token: 0x0600000B RID: 11 RVA: 0x00002360 File Offset: 0x00000560
		private void RPCCheckbox_CheckedChanged(object sender, EventArgs e)
		{
			SettingsModel settingsModel = SettingsManager.Load();
			settingsModel.DiscordRPC = this.RPCCheckbox.Checked;
			settingsModel.Save();
			if (settingsModel.DiscordRPC)
			{
				if (Globals.RPCClient.IsInitialized)
				{
					Globals.RPCClient.SetPresence(Globals.RichPresence);
					return;
				}
				Globals.RPCClient.Initialize();
				Globals.RPCClient.SetPresence(Globals.RichPresence);
				return;
			}
			else
			{
				if (Globals.RPCClient.IsInitialized)
				{
					Globals.RPCClient.ClearPresence();
					return;
				}
				Globals.RPCClient.Initialize();
				Globals.RPCClient.ClearPresence();
				return;
			}
		}

		// Token: 0x0600000C RID: 12 RVA: 0x000023F4 File Offset: 0x000005F4
		private void Manager_ConnectionErrored(object sender, string output)
		{
			MainForm._openvpn.Dispose();
			MainForm._openvpn = null;
			base.Invoke(new MethodInvoker(delegate()
			{
				this.ConnectBTN.Enabled = true;
				this.ConnectBTN.Text = Resources.Vpn_Connect;
				this.statuslbl.Text = Resources.Not_Connected;
				this.connectingIndicator.Visible = false;
				CustomMessageBox.Show("Courvix VPN", output);
			}));
			Globals.RichPresence.Timestamps = null;
			Globals.RichPresence.State = "Disconnected";
			Globals.SetRPC();
		}

		// Token: 0x0600000D RID: 13 RVA: 0x00002457 File Offset: 0x00000657
		private void Manager_Closed(object sender)
		{
			Globals.RichPresence.State = "Not Connected";
			Globals.RichPresence.Timestamps = null;
			Globals.SetRPC();
			base.Invoke(new MethodInvoker(delegate()
			{
				this.ConnectBTN.Text = Resources.Vpn_Connect;
				this.statuslbl.Text = Resources.Not_Connected;
				this.connectingIndicator.Visible = false;
				this.ConnectBTN.Enabled = true;
			}));
		}

		// Token: 0x0600000E RID: 14 RVA: 0x0000248C File Offset: 0x0000068C
		private void Manager_Connected(object sender)
		{
			Globals.RichPresence.State = "Connected to " + MainForm._connectedServer.ServerName;
			Globals.RichPresence.Timestamps = Timestamps.Now;
			Globals.SetRPC();
			base.Invoke(new MethodInvoker(delegate()
			{
				this.ConnectBTN.Text = ((MainForm._connectedServer != MainForm._servers.First((Server x) => x.ServerName == this.serversCB.Text)) ? Resources.Reconnect : Resources.Vpn_Disconnect);
				this.ConnectBTN.Enabled = true;
				this.statuslbl.Text = Resources.Connected;
				this.connectingIndicator.Visible = false;
				this.connectingIndicator.Stop();
			}));
		}

		// Token: 0x0600000F RID: 15 RVA: 0x000024DE File Offset: 0x000006DE
		private void CheckOpenVPN()
		{
			if (!File.Exists(Strings.OpenVpnPath))
			{
				CustomMessageBox.Show("Courvix VPN", Resources.OpenVpn_Not_Found);
				CustomMessageBox.Show("Courvix VPN", Resources.OpenVpn_Download_Open);
				Process.Start("https://swupdate.openvpn.org/community/releases/OpenVPN-2.5.5-I602-amd64.msi");
				Environment.Exit(1);
			}
		}

		// Token: 0x06000010 RID: 16 RVA: 0x0000251D File Offset: 0x0000071D
		private void xbtn_Click(object sender, EventArgs e)
		{
			Globals.RPCClient.Dispose();
			Application.Exit();
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002530 File Offset: 0x00000730
		private void serversCB_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (MainForm._connectedServer == null)
			{
				return;
			}
			Server server = MainForm._servers.First((Server x) => x.ServerName == this.serversCB.Text);
			this.ConnectBTN.Text = ((server != MainForm._connectedServer) ? Resources.Reconnect : Resources.Vpn_Disconnect);
		}

		// Token: 0x06000012 RID: 18 RVA: 0x0000257B File Offset: 0x0000077B
		private void btnMinimize_Click(object sender, EventArgs e)
		{
			base.Visible = false;
			this.notifyIcon1.Visible = true;
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002590 File Offset: 0x00000790
		private void openToolStripMenuItem_Click(object sender, EventArgs e)
		{
			base.Show();
			this.notifyIcon1.Visible = false;
		}

		// Token: 0x06000014 RID: 20 RVA: 0x000025A4 File Offset: 0x000007A4
		private void closeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x04000008 RID: 8
		private static readonly HttpClient _client = new HttpClient();

		// Token: 0x04000009 RID: 9
		private static List<Server> _servers;

		// Token: 0x0400000A RID: 10
		private static OpenVPN _openvpn;

		// Token: 0x0400000B RID: 11
		private static Server _connectedServer;
	}
}
