﻿namespace Courvix_VPN
{
	// Token: 0x02000004 RID: 4
	public partial class MainForm : global::System.Windows.Forms.Form
	{
		// Token: 0x06000015 RID: 21 RVA: 0x000025AB File Offset: 0x000007AB
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000016 RID: 22 RVA: 0x000025CC File Offset: 0x000007CC
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::Courvix_VPN.MainForm));
			this.headerlbl = new global::Guna.UI2.WinForms.Guna2HtmlLabel();
			this.headerbar = new global::Guna.UI2.WinForms.Guna2Separator();
			this.statuslbl = new global::Guna.UI2.WinForms.Guna2HtmlLabel();
			this.serversCB = new global::Guna.UI2.WinForms.Guna2ComboBox();
			this.xbtn = new global::Guna.UI2.WinForms.Guna2ControlBox();
			this.leftborder = new global::Guna.UI2.WinForms.Guna2Panel();
			this.rightborder = new global::Guna.UI2.WinForms.Guna2Panel();
			this.topborder = new global::Guna.UI2.WinForms.Guna2Panel();
			this.bottomborder = new global::Guna.UI2.WinForms.Guna2Panel();
			this.ConnectBTN = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2DragControl1 = new global::Guna.UI2.WinForms.Guna2DragControl(this.components);
			this.guna2BorderlessForm1 = new global::Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
			this.RPCCheckbox = new global::Guna.UI2.WinForms.Guna2CheckBox();
			this.btnMinimize = new global::Guna.UI2.WinForms.Guna2ControlBox();
			this.connectingIndicator = new global::Guna.UI2.WinForms.Guna2ProgressIndicator();
			this.lblVersion = new global::Guna.UI2.WinForms.Guna2HtmlLabel();
			this.notifyIcon1 = new global::System.Windows.Forms.NotifyIcon(this.components);
			this.guna2ContextMenuStrip1 = new global::Guna.UI2.WinForms.Guna2ContextMenuStrip();
			this.openToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.closeToolStripMenuItem = new global::System.Windows.Forms.ToolStripMenuItem();
			this.guna2ContextMenuStrip1.SuspendLayout();
			base.SuspendLayout();
			this.headerlbl.BackColor = global::System.Drawing.Color.Transparent;
			this.headerlbl.Font = new global::System.Drawing.Font("Segoe UI Semibold", 15.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.headerlbl.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.headerlbl.IsSelectionEnabled = false;
			this.headerlbl.Location = new global::System.Drawing.Point(121, 17);
			this.headerlbl.Name = "headerlbl";
			this.headerlbl.Size = new global::System.Drawing.Size(123, 32);
			this.headerlbl.TabIndex = 0;
			this.headerlbl.Text = "Courvix VPN";
			this.headerbar.FillColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.headerbar.FillThickness = 2;
			this.headerbar.Location = new global::System.Drawing.Point(12, 61);
			this.headerbar.Name = "headerbar";
			this.headerbar.Size = new global::System.Drawing.Size(340, 11);
			this.headerbar.TabIndex = 1;
			this.statuslbl.BackColor = global::System.Drawing.Color.Transparent;
			this.statuslbl.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.statuslbl.ForeColor = global::System.Drawing.Color.White;
			this.statuslbl.IsSelectionEnabled = false;
			this.statuslbl.Location = new global::System.Drawing.Point(3, 415);
			this.statuslbl.Name = "statuslbl";
			this.statuslbl.Size = new global::System.Drawing.Size(38, 17);
			this.statuslbl.TabIndex = 2;
			this.statuslbl.Text = "Status:";
			this.serversCB.Animated = true;
			this.serversCB.BackColor = global::System.Drawing.Color.Transparent;
			this.serversCB.BorderColor = global::System.Drawing.Color.FromArgb(10, 11, 17);
			this.serversCB.DrawMode = global::System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.serversCB.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.serversCB.FillColor = global::System.Drawing.Color.FromArgb(12, 14, 21);
			this.serversCB.FocusedColor = global::System.Drawing.Color.FromArgb(10, 11, 50);
			this.serversCB.FocusedState.BorderColor = global::System.Drawing.Color.FromArgb(10, 11, 50);
			this.serversCB.FocusedState.Parent = this.serversCB;
			this.serversCB.Font = new global::System.Drawing.Font("Segoe UI", 10f);
			this.serversCB.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.serversCB.HoverState.Parent = this.serversCB;
			this.serversCB.ItemHeight = 30;
			this.serversCB.Items.AddRange(new object[]
			{
				"CONNECTION-1",
				"CONNECTION-2",
				"CONNECTION-3",
				"CONNECTION-4",
				"CONNECTION-5"
			});
			this.serversCB.ItemsAppearance.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.serversCB.ItemsAppearance.Parent = this.serversCB;
			this.serversCB.ItemsAppearance.SelectedBackColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.serversCB.Location = new global::System.Drawing.Point(12, 135);
			this.serversCB.Name = "serversCB";
			this.serversCB.ShadowDecoration.Color = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.serversCB.ShadowDecoration.Enabled = true;
			this.serversCB.ShadowDecoration.Parent = this.serversCB;
			this.serversCB.Size = new global::System.Drawing.Size(340, 36);
			this.serversCB.TabIndex = 3;
			this.serversCB.SelectedIndexChanged += new global::System.EventHandler(this.serversCB_SelectedIndexChanged);
			this.xbtn.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.xbtn.FillColor = global::System.Drawing.Color.FromArgb(12, 14, 21);
			this.xbtn.HoverState.FillColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.xbtn.HoverState.Parent = this.xbtn;
			this.xbtn.IconColor = global::System.Drawing.Color.White;
			this.xbtn.Location = new global::System.Drawing.Point(319, 1);
			this.xbtn.Name = "xbtn";
			this.xbtn.ShadowDecoration.Parent = this.xbtn;
			this.xbtn.Size = new global::System.Drawing.Size(45, 29);
			this.xbtn.TabIndex = 4;
			this.xbtn.Click += new global::System.EventHandler(this.xbtn_Click);
			this.leftborder.BackColor = global::System.Drawing.Color.FromArgb(10, 11, 17);
			this.leftborder.Dock = global::System.Windows.Forms.DockStyle.Left;
			this.leftborder.Location = new global::System.Drawing.Point(0, 0);
			this.leftborder.Name = "leftborder";
			this.leftborder.ShadowDecoration.Parent = this.leftborder;
			this.leftborder.Size = new global::System.Drawing.Size(3, 435);
			this.leftborder.TabIndex = 5;
			this.rightborder.BackColor = global::System.Drawing.Color.FromArgb(10, 11, 17);
			this.rightborder.Dock = global::System.Windows.Forms.DockStyle.Right;
			this.rightborder.Location = new global::System.Drawing.Point(361, 0);
			this.rightborder.Name = "rightborder";
			this.rightborder.ShadowDecoration.Parent = this.rightborder;
			this.rightborder.Size = new global::System.Drawing.Size(3, 435);
			this.rightborder.TabIndex = 6;
			this.topborder.BackColor = global::System.Drawing.Color.FromArgb(10, 11, 17);
			this.topborder.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.topborder.Location = new global::System.Drawing.Point(3, 0);
			this.topborder.Name = "topborder";
			this.topborder.ShadowDecoration.Parent = this.topborder;
			this.topborder.Size = new global::System.Drawing.Size(358, 3);
			this.topborder.TabIndex = 7;
			this.bottomborder.BackColor = global::System.Drawing.Color.FromArgb(10, 11, 17);
			this.bottomborder.Dock = global::System.Windows.Forms.DockStyle.Bottom;
			this.bottomborder.Location = new global::System.Drawing.Point(3, 432);
			this.bottomborder.Name = "bottomborder";
			this.bottomborder.ShadowDecoration.Parent = this.bottomborder;
			this.bottomborder.Size = new global::System.Drawing.Size(358, 3);
			this.bottomborder.TabIndex = 8;
			this.ConnectBTN.Animated = true;
			this.ConnectBTN.BackColor = global::System.Drawing.Color.Transparent;
			this.ConnectBTN.BorderColor = global::System.Drawing.Color.FromArgb(10, 11, 17);
			this.ConnectBTN.BorderRadius = 3;
			this.ConnectBTN.ButtonMode = 2;
			this.ConnectBTN.CheckedState.Parent = this.ConnectBTN;
			this.ConnectBTN.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.ConnectBTN.CustomImages.Parent = this.ConnectBTN;
			this.ConnectBTN.DisabledState.Parent = this.ConnectBTN;
			this.ConnectBTN.FillColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.ConnectBTN.Font = new global::System.Drawing.Font("Segoe UI Semibold", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ConnectBTN.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.ConnectBTN.HoverState.Parent = this.ConnectBTN;
			this.ConnectBTN.Location = new global::System.Drawing.Point(48, 270);
			this.ConnectBTN.Name = "ConnectBTN";
			this.ConnectBTN.PressedColor = global::System.Drawing.Color.WhiteSmoke;
			this.ConnectBTN.ShadowDecoration.Color = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.ConnectBTN.ShadowDecoration.Enabled = true;
			this.ConnectBTN.ShadowDecoration.Parent = this.ConnectBTN;
			this.ConnectBTN.Size = new global::System.Drawing.Size(267, 45);
			this.ConnectBTN.TabIndex = 9;
			this.ConnectBTN.Text = "Connect";
			this.ConnectBTN.Click += new global::System.EventHandler(this.ConnectBTN_Click);
			this.guna2DragControl1.ContainerControl = this;
			this.guna2DragControl1.DockIndicatorTransparencyValue = 0.6;
			this.guna2DragControl1.TargetControl = this.headerlbl;
			this.guna2DragControl1.UseTransparentDrag = true;
			this.guna2BorderlessForm1.AnimateWindow = true;
			this.guna2BorderlessForm1.AnimationInterval = 100;
			this.guna2BorderlessForm1.BorderRadius = 2;
			this.guna2BorderlessForm1.ContainerControl = this;
			this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
			this.guna2BorderlessForm1.ResizeForm = false;
			this.guna2BorderlessForm1.ShadowColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.guna2BorderlessForm1.TransparentWhileDrag = true;
			this.RPCCheckbox.Animated = true;
			this.RPCCheckbox.AutoSize = true;
			this.RPCCheckbox.CheckedState.BorderColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.RPCCheckbox.CheckedState.BorderRadius = 2;
			this.RPCCheckbox.CheckedState.BorderThickness = 1;
			this.RPCCheckbox.CheckedState.FillColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.RPCCheckbox.CheckMarkColor = global::System.Drawing.Color.WhiteSmoke;
			this.RPCCheckbox.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.RPCCheckbox.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.RPCCheckbox.Location = new global::System.Drawing.Point(203, 413);
			this.RPCCheckbox.Name = "RPCCheckbox";
			this.RPCCheckbox.Size = new global::System.Drawing.Size(152, 19);
			this.RPCCheckbox.TabIndex = 10;
			this.RPCCheckbox.Text = "Show Status On Discord";
			this.RPCCheckbox.UncheckedState.BorderColor = global::System.Drawing.Color.FromArgb(125, 137, 149);
			this.RPCCheckbox.UncheckedState.BorderRadius = 2;
			this.RPCCheckbox.UncheckedState.BorderThickness = 1;
			this.RPCCheckbox.UncheckedState.FillColor = global::System.Drawing.Color.FromArgb(12, 14, 21);
			this.RPCCheckbox.CheckedChanged += new global::System.EventHandler(this.RPCCheckbox_CheckedChanged);
			this.btnMinimize.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.btnMinimize.ControlBoxType = 0;
			this.btnMinimize.FillColor = global::System.Drawing.Color.FromArgb(12, 14, 21);
			this.btnMinimize.HoverState.FillColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.btnMinimize.HoverState.Parent = this.btnMinimize;
			this.btnMinimize.IconColor = global::System.Drawing.Color.White;
			this.btnMinimize.Location = new global::System.Drawing.Point(270, 3);
			this.btnMinimize.Name = "btnMinimize";
			this.btnMinimize.ShadowDecoration.Parent = this.btnMinimize;
			this.btnMinimize.Size = new global::System.Drawing.Size(45, 29);
			this.btnMinimize.TabIndex = 11;
			this.btnMinimize.Click += new global::System.EventHandler(this.btnMinimize_Click);
			this.connectingIndicator.CircleSize = 1f;
			this.connectingIndicator.Location = new global::System.Drawing.Point(107, 416);
			this.connectingIndicator.Name = "connectingIndicator";
			this.connectingIndicator.ProgressColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.connectingIndicator.ShadowDecoration.Parent = this.connectingIndicator;
			this.connectingIndicator.Size = new global::System.Drawing.Size(17, 13);
			this.connectingIndicator.TabIndex = 12;
			this.connectingIndicator.Visible = false;
			this.lblVersion.BackColor = global::System.Drawing.Color.Transparent;
			this.lblVersion.Font = new global::System.Drawing.Font("Segoe UI Semibold", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblVersion.ForeColor = global::System.Drawing.Color.White;
			this.lblVersion.Location = new global::System.Drawing.Point(3, 4);
			this.lblVersion.Name = "lblVersion";
			this.lblVersion.Size = new global::System.Drawing.Size(60, 15);
			this.lblVersion.TabIndex = 13;
			this.lblVersion.Text = "version n/a";
			this.notifyIcon1.ContextMenuStrip = this.guna2ContextMenuStrip1;
			this.notifyIcon1.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("notifyIcon1.Icon");
			this.notifyIcon1.Text = "Courvix VPN";
			this.guna2ContextMenuStrip1.BackColor = global::System.Drawing.Color.FromArgb(12, 14, 21);
			this.guna2ContextMenuStrip1.Items.AddRange(new global::System.Windows.Forms.ToolStripItem[]
			{
				this.openToolStripMenuItem,
				this.closeToolStripMenuItem
			});
			this.guna2ContextMenuStrip1.Name = "guna2ContextMenuStrip1";
			this.guna2ContextMenuStrip1.RenderStyle.ArrowColor = global::System.Drawing.Color.WhiteSmoke;
			this.guna2ContextMenuStrip1.RenderStyle.BorderColor = global::System.Drawing.Color.FromArgb(10, 11, 17);
			this.guna2ContextMenuStrip1.RenderStyle.ColorTable = null;
			this.guna2ContextMenuStrip1.RenderStyle.RoundedEdges = true;
			this.guna2ContextMenuStrip1.RenderStyle.SelectionArrowColor = global::System.Drawing.Color.WhiteSmoke;
			this.guna2ContextMenuStrip1.RenderStyle.SelectionBackColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.guna2ContextMenuStrip1.RenderStyle.SelectionForeColor = global::System.Drawing.Color.White;
			this.guna2ContextMenuStrip1.RenderStyle.SeparatorColor = global::System.Drawing.Color.FromArgb(10, 11, 17);
			this.guna2ContextMenuStrip1.RenderStyle.TextRenderingHint = global::System.Drawing.Text.TextRenderingHint.SystemDefault;
			this.guna2ContextMenuStrip1.Size = new global::System.Drawing.Size(104, 48);
			this.openToolStripMenuItem.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.openToolStripMenuItem.Name = "openToolStripMenuItem";
			this.openToolStripMenuItem.Size = new global::System.Drawing.Size(103, 22);
			this.openToolStripMenuItem.Text = "Open";
			this.openToolStripMenuItem.Click += new global::System.EventHandler(this.openToolStripMenuItem_Click);
			this.closeToolStripMenuItem.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
			this.closeToolStripMenuItem.Size = new global::System.Drawing.Size(103, 22);
			this.closeToolStripMenuItem.Text = "Close";
			this.closeToolStripMenuItem.Click += new global::System.EventHandler(this.closeToolStripMenuItem_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(12, 14, 21);
			base.ClientSize = new global::System.Drawing.Size(364, 435);
			base.Controls.Add(this.lblVersion);
			base.Controls.Add(this.connectingIndicator);
			base.Controls.Add(this.btnMinimize);
			base.Controls.Add(this.RPCCheckbox);
			base.Controls.Add(this.ConnectBTN);
			base.Controls.Add(this.bottomborder);
			base.Controls.Add(this.topborder);
			base.Controls.Add(this.rightborder);
			base.Controls.Add(this.leftborder);
			base.Controls.Add(this.xbtn);
			base.Controls.Add(this.serversCB);
			base.Controls.Add(this.statuslbl);
			base.Controls.Add(this.headerbar);
			base.Controls.Add(this.headerlbl);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "MainForm";
			this.Text = "Courvix VPN";
			base.Load += new global::System.EventHandler(this.MainForm_Load);
			this.guna2ContextMenuStrip1.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400000C RID: 12
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400000D RID: 13
		private global::System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;

		// Token: 0x0400000E RID: 14
		private global::System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;

		// Token: 0x0400000F RID: 15
		private global::System.Windows.Forms.NotifyIcon notifyIcon1;

		// Token: 0x04000010 RID: 16
		private global::Guna.UI2.WinForms.Guna2ContextMenuStrip guna2ContextMenuStrip1;

		// Token: 0x04000011 RID: 17
		private global::Guna.UI2.WinForms.Guna2HtmlLabel headerlbl;

		// Token: 0x04000012 RID: 18
		private global::Guna.UI2.WinForms.Guna2Separator headerbar;

		// Token: 0x04000013 RID: 19
		private global::Guna.UI2.WinForms.Guna2HtmlLabel statuslbl;

		// Token: 0x04000014 RID: 20
		private global::Guna.UI2.WinForms.Guna2ComboBox serversCB;

		// Token: 0x04000015 RID: 21
		private global::Guna.UI2.WinForms.Guna2ControlBox xbtn;

		// Token: 0x04000016 RID: 22
		private global::Guna.UI2.WinForms.Guna2Panel leftborder;

		// Token: 0x04000017 RID: 23
		private global::Guna.UI2.WinForms.Guna2Panel rightborder;

		// Token: 0x04000018 RID: 24
		private global::Guna.UI2.WinForms.Guna2Panel topborder;

		// Token: 0x04000019 RID: 25
		private global::Guna.UI2.WinForms.Guna2Panel bottomborder;

		// Token: 0x0400001A RID: 26
		private global::Guna.UI2.WinForms.Guna2Button ConnectBTN;

		// Token: 0x0400001B RID: 27
		private global::Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;

		// Token: 0x0400001C RID: 28
		private global::Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;

		// Token: 0x0400001D RID: 29
		private global::Guna.UI2.WinForms.Guna2CheckBox RPCCheckbox;

		// Token: 0x0400001E RID: 30
		private global::Guna.UI2.WinForms.Guna2ControlBox btnMinimize;

		// Token: 0x0400001F RID: 31
		private global::Guna.UI2.WinForms.Guna2ProgressIndicator connectingIndicator;

		// Token: 0x04000020 RID: 32
		private global::Guna.UI2.WinForms.Guna2HtmlLabel lblVersion;
	}
}
