﻿using System;
using System.IO;
using Microsoft.Win32;

namespace Courvix_VPN
{
	// Token: 0x0200000F RID: 15
	public static class Strings
	{
		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000037 RID: 55 RVA: 0x000043A8 File Offset: 0x000025A8
		public static string OpenVpnPath
		{
			get
			{
				if (Strings._openVpnPath != null)
				{
					return Strings._openVpnPath;
				}
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE"))
				{
					using (RegistryKey registryKey2 = registryKey.OpenSubKey("OpenVPN"))
					{
						string openVpnPath;
						if (registryKey2 == null)
						{
							openVpnPath = null;
						}
						else
						{
							object value = registryKey2.GetValue("exe_path");
							openVpnPath = ((value != null) ? value.ToString() : null);
						}
						Strings._openVpnPath = openVpnPath;
					}
				}
				return Strings._openVpnPath;
			}
		}

		// Token: 0x04000045 RID: 69
		private static string _openVpnPath;

		// Token: 0x04000046 RID: 70
		public static readonly string Data = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Courvix");

		// Token: 0x04000047 RID: 71
		public static readonly string ErrorLogs = Path.Combine(Strings.Data, "error.log");

		// Token: 0x04000048 RID: 72
		public static readonly string OpenVpnLogs = Path.Combine(Strings.Data, "openvpnoutput.txt");

		// Token: 0x04000049 RID: 73
		public static readonly string ConfigDirectory = Path.Combine(Strings.Data, "configs");
	}
}
