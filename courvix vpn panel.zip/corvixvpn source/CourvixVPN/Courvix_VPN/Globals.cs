﻿using System;
using DiscordRPC;

namespace Courvix_VPN
{
	// Token: 0x0200000B RID: 11
	public static class Globals
	{
		// Token: 0x0600002D RID: 45 RVA: 0x000041D2 File Offset: 0x000023D2
		public static void SetRPC()
		{
			if (SettingsManager.Load().DiscordRPC)
			{
				Globals.RPCClient.SetPresence(Globals.RichPresence);
			}
		}

		// Token: 0x04000040 RID: 64
		public static DiscordRpcClient RPCClient = new DiscordRpcClient("939276152797814834");

		// Token: 0x04000041 RID: 65
		public static readonly RichPresence RichPresence = new RichPresence
		{
			State = "Not Connected",
			Assets = new Assets
			{
				LargeImageKey = "network_plain",
				SmallImageKey = "small"
			},
			Buttons = new Button[]
			{
				new Button
				{
					Label = "Website",
					Url = "https://courvix.com"
				}
			}
		};
	}
}
