﻿using System;
using System.IO;
using System.Windows.Forms;
using Courvix_VPN.Forms;
using Courvix_VPN.Properties;

namespace Courvix_VPN
{
	// Token: 0x0200000C RID: 12
	internal static class Program
	{
		// Token: 0x0600002F RID: 47 RVA: 0x0000426E File Offset: 0x0000246E
		[STAThread]
		private static void Main()
		{
			AppDomain.CurrentDomain.UnhandledException += Program.CurrentDomainOnUnhandledException;
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new MainForm());
		}

		// Token: 0x06000030 RID: 48 RVA: 0x0000429B File Offset: 0x0000249B
		private static void CurrentDomainOnUnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			CustomMessageBox.Show("Courvix VPN", Resources.UnhandledException);
			string errorLogs = Strings.ErrorLogs;
			Exception ex = e.ExceptionObject as Exception;
			File.AppendAllText(errorLogs, (ex != null) ? ex.ToString() : null);
		}
	}
}
