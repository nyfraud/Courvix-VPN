﻿using System;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace Courvix_VPN
{
	// Token: 0x02000002 RID: 2
	public static class Extensions
	{
		// Token: 0x06000002 RID: 2 RVA: 0x00002058 File Offset: 0x00000258
		public static Task<T> GetAsync<T>(this HttpClient _client, string url, CancellationToken cancellationToken = default(CancellationToken))
		{
			Extensions.<GetAsync>d__0<T> <GetAsync>d__;
			<GetAsync>d__.<>t__builder = AsyncTaskMethodBuilder<T>.Create();
			<GetAsync>d__._client = _client;
			<GetAsync>d__.url = url;
			<GetAsync>d__.<>1__state = -1;
			<GetAsync>d__.<>t__builder.Start<Extensions.<GetAsync>d__0<T>>(ref <GetAsync>d__);
			return <GetAsync>d__.<>t__builder.Task;
		}
	}
}
