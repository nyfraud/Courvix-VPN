﻿namespace Courvix_VPN.Forms
{
	// Token: 0x02000014 RID: 20
	public partial class CustomMessageBox : global::System.Windows.Forms.Form
	{
		// Token: 0x0600006E RID: 110 RVA: 0x0000477C File Offset: 0x0000297C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600006F RID: 111 RVA: 0x0000479C File Offset: 0x0000299C
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			this.guna2BorderlessForm1 = new global::Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
			this.guna2Panel1 = new global::Guna.UI2.WinForms.Guna2Panel();
			this.guna2ControlBox1 = new global::Guna.UI2.WinForms.Guna2ControlBox();
			this.title = new global::Guna.UI2.WinForms.Guna2HtmlLabel();
			this.guna2Separator1 = new global::Guna.UI2.WinForms.Guna2Separator();
			this.description = new global::Guna.UI2.WinForms.Guna2HtmlLabel();
			this.guna2DragControl1 = new global::Guna.UI2.WinForms.Guna2DragControl(this.components);
			this.guna2Panel1.SuspendLayout();
			base.SuspendLayout();
			this.guna2BorderlessForm1.AnimateWindow = true;
			this.guna2BorderlessForm1.AnimationInterval = 125;
			this.guna2BorderlessForm1.BorderRadius = 5;
			this.guna2BorderlessForm1.ContainerControl = this;
			this.guna2BorderlessForm1.TransparentWhileDrag = true;
			this.guna2Panel1.Controls.Add(this.guna2ControlBox1);
			this.guna2Panel1.Controls.Add(this.title);
			this.guna2Panel1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.guna2Panel1.Location = new global::System.Drawing.Point(0, 0);
			this.guna2Panel1.Name = "guna2Panel1";
			this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
			this.guna2Panel1.Size = new global::System.Drawing.Size(455, 32);
			this.guna2Panel1.TabIndex = 0;
			this.guna2ControlBox1.Animated = true;
			this.guna2ControlBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2ControlBox1.ControlBoxStyle = 1;
			this.guna2ControlBox1.Dock = global::System.Windows.Forms.DockStyle.Right;
			this.guna2ControlBox1.FillColor = global::System.Drawing.Color.FromArgb(12, 14, 21);
			this.guna2ControlBox1.HoverState.Parent = this.guna2ControlBox1;
			this.guna2ControlBox1.IconColor = global::System.Drawing.Color.White;
			this.guna2ControlBox1.Location = new global::System.Drawing.Point(410, 0);
			this.guna2ControlBox1.Name = "guna2ControlBox1";
			this.guna2ControlBox1.ShadowDecoration.Parent = this.guna2ControlBox1;
			this.guna2ControlBox1.Size = new global::System.Drawing.Size(45, 32);
			this.guna2ControlBox1.TabIndex = 1;
			this.guna2ControlBox1.TabStop = false;
			this.guna2ControlBox1.Click += new global::System.EventHandler(this.guna2ControlBox1_Click);
			this.title.BackColor = global::System.Drawing.Color.Transparent;
			this.title.Font = new global::System.Drawing.Font("Segoe UI Semibold", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.title.ForeColor = global::System.Drawing.Color.White;
			this.title.IsContextMenuEnabled = false;
			this.title.IsSelectionEnabled = false;
			this.title.Location = new global::System.Drawing.Point(3, 5);
			this.title.Name = "title";
			this.title.Size = new global::System.Drawing.Size(32, 22);
			this.title.TabIndex = 0;
			this.title.TabStop = false;
			this.title.Text = "Title";
			this.title.TextAlignment = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.guna2Separator1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.guna2Separator1.FillColor = global::System.Drawing.Color.FromArgb(0, 99, 204);
			this.guna2Separator1.Location = new global::System.Drawing.Point(0, 32);
			this.guna2Separator1.Name = "guna2Separator1";
			this.guna2Separator1.Size = new global::System.Drawing.Size(455, 10);
			this.guna2Separator1.TabIndex = 1;
			this.description.BackColor = global::System.Drawing.Color.Transparent;
			this.description.Font = new global::System.Drawing.Font("Segoe UI Semibold", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.description.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.description.IsContextMenuEnabled = false;
			this.description.IsSelectionEnabled = false;
			this.description.Location = new global::System.Drawing.Point(3, 48);
			this.description.MaximumSize = new global::System.Drawing.Size(600, 280);
			this.description.Name = "description";
			this.description.Size = new global::System.Drawing.Size(81, 22);
			this.description.TabIndex = 2;
			this.description.Text = "Description";
			this.guna2DragControl1.ContainerControl = this;
			this.guna2DragControl1.TargetControl = this.guna2Panel1;
			this.guna2DragControl1.TransparentWhileDrag = true;
			this.guna2DragControl1.UseTransparentDrag = true;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.AutoScroll = true;
			this.AutoSize = true;
			base.AutoSizeMode = global::System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.BackColor = global::System.Drawing.Color.FromArgb(12, 14, 21);
			base.ClientSize = new global::System.Drawing.Size(455, 226);
			base.Controls.Add(this.description);
			base.Controls.Add(this.guna2Separator1);
			base.Controls.Add(this.guna2Panel1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			this.MaximumSize = new global::System.Drawing.Size(626, 336);
			this.MinimumSize = new global::System.Drawing.Size(455, 226);
			base.Name = "CustomMessageBox";
			this.Text = "CustomMessageBox";
			base.Load += new global::System.EventHandler(this.CustomMessageBox_Load);
			this.guna2Panel1.ResumeLayout(false);
			this.guna2Panel1.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000058 RID: 88
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000059 RID: 89
		private global::Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;

		// Token: 0x0400005A RID: 90
		private global::Guna.UI2.WinForms.Guna2Panel guna2Panel1;

		// Token: 0x0400005B RID: 91
		private global::Guna.UI2.WinForms.Guna2Separator guna2Separator1;

		// Token: 0x0400005C RID: 92
		private global::Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;

		// Token: 0x0400005D RID: 93
		private global::Guna.UI2.WinForms.Guna2HtmlLabel title;

		// Token: 0x0400005E RID: 94
		private global::Guna.UI2.WinForms.Guna2HtmlLabel description;

		// Token: 0x0400005F RID: 95
		private global::Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
	}
}
