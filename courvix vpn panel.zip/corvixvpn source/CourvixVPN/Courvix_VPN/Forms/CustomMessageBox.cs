﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Guna.UI2.WinForms;

namespace Courvix_VPN.Forms
{
	// Token: 0x02000014 RID: 20
	public partial class CustomMessageBox : Form
	{
		// Token: 0x0600006A RID: 106 RVA: 0x0000473E File Offset: 0x0000293E
		public CustomMessageBox(string title, string message)
		{
			this.InitializeComponent();
			this.title.Text = title;
			this.description.Text = message;
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00004764 File Offset: 0x00002964
		public static DialogResult Show(string title, string description)
		{
			return new CustomMessageBox(title, description).ShowDialog();
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00004772 File Offset: 0x00002972
		private void guna2ControlBox1_Click(object sender, EventArgs e)
		{
			base.Close();
		}

		// Token: 0x0600006D RID: 109 RVA: 0x0000477A File Offset: 0x0000297A
		private void CustomMessageBox_Load(object sender, EventArgs e)
		{
		}
	}
}
