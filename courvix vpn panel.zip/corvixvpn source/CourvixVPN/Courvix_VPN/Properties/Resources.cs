﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Courvix_VPN.Properties
{
	// Token: 0x02000010 RID: 16
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000039 RID: 57 RVA: 0x0000380C File Offset: 0x00001A0C
		internal Resources()
		{
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600003A RID: 58 RVA: 0x00004497 File Offset: 0x00002697
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = new ResourceManager("Courvix_VPN.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x0600003B RID: 59 RVA: 0x000044C3 File Offset: 0x000026C3
		// (set) Token: 0x0600003C RID: 60 RVA: 0x000044CA File Offset: 0x000026CA
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x0600003D RID: 61 RVA: 0x000044D2 File Offset: 0x000026D2
		internal static string Checking_For_OpenVPN
		{
			get
			{
				return Resources.ResourceManager.GetString("Checking_For_OpenVPN", Resources.resourceCulture);
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x0600003E RID: 62 RVA: 0x000044E8 File Offset: 0x000026E8
		internal static string Checking_For_Updates
		{
			get
			{
				return Resources.ResourceManager.GetString("Checking_For_Updates", Resources.resourceCulture);
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x0600003F RID: 63 RVA: 0x000044FE File Offset: 0x000026FE
		internal static string Connected
		{
			get
			{
				return Resources.ResourceManager.GetString("Connected", Resources.resourceCulture);
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000040 RID: 64 RVA: 0x00004514 File Offset: 0x00002714
		internal static string Downloading_Config
		{
			get
			{
				return Resources.ResourceManager.GetString("Downloading_Config", Resources.resourceCulture);
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000041 RID: 65 RVA: 0x0000452A File Offset: 0x0000272A
		internal static string Downloading_Update
		{
			get
			{
				return Resources.ResourceManager.GetString("Downloading_Update", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000042 RID: 66 RVA: 0x00004540 File Offset: 0x00002740
		internal static string Failed_Download_Config
		{
			get
			{
				return Resources.ResourceManager.GetString("Failed_Download_Config", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000043 RID: 67 RVA: 0x00004556 File Offset: 0x00002756
		internal static string Getting_Servers
		{
			get
			{
				return Resources.ResourceManager.GetString("Getting_Servers", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000044 RID: 68 RVA: 0x0000456C File Offset: 0x0000276C
		internal static string New_Version_Found
		{
			get
			{
				return Resources.ResourceManager.GetString("New_Version_Found", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000045 RID: 69 RVA: 0x00004582 File Offset: 0x00002782
		internal static string Not_Connected
		{
			get
			{
				return Resources.ResourceManager.GetString("Not_Connected", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000046 RID: 70 RVA: 0x00004598 File Offset: 0x00002798
		internal static string OpenVpn_Download_Open
		{
			get
			{
				return Resources.ResourceManager.GetString("OpenVpn_Download_Open", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000047 RID: 71 RVA: 0x000045AE File Offset: 0x000027AE
		internal static string OpenVpn_Not_Found
		{
			get
			{
				return Resources.ResourceManager.GetString("OpenVpn_Not_Found", Resources.resourceCulture);
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000048 RID: 72 RVA: 0x000045C4 File Offset: 0x000027C4
		internal static string Reconnect
		{
			get
			{
				return Resources.ResourceManager.GetString("Reconnect", Resources.resourceCulture);
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000049 RID: 73 RVA: 0x000045DA File Offset: 0x000027DA
		internal static string Server_Load_Failed
		{
			get
			{
				return Resources.ResourceManager.GetString("Server_Load_Failed", Resources.resourceCulture);
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x0600004A RID: 74 RVA: 0x000045F0 File Offset: 0x000027F0
		internal static string Status_Vpn_Connecting
		{
			get
			{
				return Resources.ResourceManager.GetString("Status_Vpn_Connecting", Resources.resourceCulture);
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x0600004B RID: 75 RVA: 0x00004606 File Offset: 0x00002806
		internal static string UnhandledException
		{
			get
			{
				return Resources.ResourceManager.GetString("UnhandledException", Resources.resourceCulture);
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x0600004C RID: 76 RVA: 0x0000461C File Offset: 0x0000281C
		internal static string Vpn_Connect
		{
			get
			{
				return Resources.ResourceManager.GetString("Vpn_Connect", Resources.resourceCulture);
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x0600004D RID: 77 RVA: 0x00004632 File Offset: 0x00002832
		internal static string Vpn_Connecting
		{
			get
			{
				return Resources.ResourceManager.GetString("Vpn_Connecting", Resources.resourceCulture);
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x0600004E RID: 78 RVA: 0x00004648 File Offset: 0x00002848
		internal static string Vpn_Disconnect
		{
			get
			{
				return Resources.ResourceManager.GetString("Vpn_Disconnect", Resources.resourceCulture);
			}
		}

		// Token: 0x0400004A RID: 74
		private static ResourceManager resourceMan;

		// Token: 0x0400004B RID: 75
		private static CultureInfo resourceCulture;
	}
}
