﻿using System;
using Newtonsoft.Json;

namespace Courvix_VPN.Models
{
	// Token: 0x02000013 RID: 19
	public class ClientVersion
	{
		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000065 RID: 101 RVA: 0x0000471C File Offset: 0x0000291C
		// (set) Token: 0x06000066 RID: 102 RVA: 0x00004724 File Offset: 0x00002924
		[JsonProperty("version")]
		public Version Version { get; set; }

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x06000067 RID: 103 RVA: 0x0000472D File Offset: 0x0000292D
		// (set) Token: 0x06000068 RID: 104 RVA: 0x00004735 File Offset: 0x00002935
		[JsonProperty("download")]
		public string DownloadLink { get; set; }
	}
}
