﻿using System;
using Newtonsoft.Json;

namespace Courvix_VPN.Models
{
	// Token: 0x02000012 RID: 18
	public class Server
	{
		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000052 RID: 82 RVA: 0x00004683 File Offset: 0x00002883
		// (set) Token: 0x06000053 RID: 83 RVA: 0x0000468B File Offset: 0x0000288B
		[JsonProperty("flagurl")]
		public string FlagUrl { get; set; }

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000054 RID: 84 RVA: 0x00004694 File Offset: 0x00002894
		// (set) Token: 0x06000055 RID: 85 RVA: 0x0000469C File Offset: 0x0000289C
		[JsonProperty("flagurl_small")]
		public string FlagUrlSmall { get; set; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000056 RID: 86 RVA: 0x000046A5 File Offset: 0x000028A5
		// (set) Token: 0x06000057 RID: 87 RVA: 0x000046AD File Offset: 0x000028AD
		[JsonProperty("provider")]
		public string Provider { get; set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000058 RID: 88 RVA: 0x000046B6 File Offset: 0x000028B6
		// (set) Token: 0x06000059 RID: 89 RVA: 0x000046BE File Offset: 0x000028BE
		[JsonProperty("protection")]
		public string Protection { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x0600005A RID: 90 RVA: 0x000046C7 File Offset: 0x000028C7
		// (set) Token: 0x0600005B RID: 91 RVA: 0x000046CF File Offset: 0x000028CF
		[JsonProperty("countrycode")]
		public string CountryCode { get; set; }

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x0600005C RID: 92 RVA: 0x000046D8 File Offset: 0x000028D8
		// (set) Token: 0x0600005D RID: 93 RVA: 0x000046E0 File Offset: 0x000028E0
		[JsonProperty("enabled")]
		public bool Enabled { get; set; }

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x0600005E RID: 94 RVA: 0x000046E9 File Offset: 0x000028E9
		// (set) Token: 0x0600005F RID: 95 RVA: 0x000046F1 File Offset: 0x000028F1
		[JsonProperty("down")]
		public bool Down { get; set; }

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000060 RID: 96 RVA: 0x000046FA File Offset: 0x000028FA
		// (set) Token: 0x06000061 RID: 97 RVA: 0x00004702 File Offset: 0x00002902
		[JsonProperty("url")]
		public string ConfigLink { get; set; }

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000062 RID: 98 RVA: 0x0000470B File Offset: 0x0000290B
		// (set) Token: 0x06000063 RID: 99 RVA: 0x00004713 File Offset: 0x00002913
		[JsonProperty("servername")]
		public string ServerName { get; set; }
	}
}
