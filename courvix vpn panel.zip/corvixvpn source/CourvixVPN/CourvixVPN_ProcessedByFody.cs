﻿using System;

// Token: 0x02000016 RID: 22
internal class CourvixVPN_ProcessedByFody
{
	// Token: 0x04000065 RID: 101
	internal const string FodyVersion = "6.6.0.0";

	// Token: 0x04000066 RID: 102
	internal const string Costura = "5.7.0";
}
